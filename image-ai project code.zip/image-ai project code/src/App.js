import './App.css';
import ImageGenerator from './Components/ImageGen/ImageGenerator'; 

function App() {
  return (
    <div>
< ImageGenerator/>
    </div>
  );
}

export default App;
