import React from 'react'
import './css/LoginsignUp.css'

export const LoginSignup = () => {
  return (
    <div className='loginsignup'>
      <div className='loginsignup-container'>
        <h1>Sign Up</h1>
        <div className='loginsignup-fields'>
          <input type='text' placeholder='your name' />
          <input type='email' placeholder='your email address' />
          <input type='password' placeholder='password' />
          </div>
          <button>Continue</button>
          <p className='loginsignup-login'>
            Already have an accout?<span>Login here</span>
          </p>
          <div className='loginsignup-agree'>
            <input type='checkbox' name='' id='' />
            <p>
              By continuing by using the terms ,privoucy and policy
            </p>
          </div>

        </div>
      </div>
    
  )
}

export default LoginSignup
