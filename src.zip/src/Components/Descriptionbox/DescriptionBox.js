import React from 'react'
import './DescriptionBox.css'

export const DescriptionBox = () => {
  return (
    <div className='descriptionbox'>
        <div className='descriptionbox-navigator'>
            <div className='descriptionbox-nav-box'>

Description
            </div>
            <div className='descriptionbox-nav-box fade'>
                Reviews(122)
                

            </div>
        </div>
        <div className='descriptionbox-description'>
            <p>

A jacket is a garment for the upper body, usually extending below the hips. A jacket typically has sleeves and fastens in the front or slightly on the side. A jacket is generally lighter, tighter-fitting, and less insulating than a coat, which is outerwear.
            </p>
           
        </div>




    </div>
  )
}
