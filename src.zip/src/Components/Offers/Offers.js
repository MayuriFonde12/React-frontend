import React from 'react'
import './Offers.css'
import exclusive_image from '../Assets/exclusive_image.png'
export const Offers = () => {
  return (
    <div className='Offers'>
        <div className='offers-left'>
            <h1>
                EXCLUSIVE
            </h1>
            <h1>Offers for you</h1>
            <p>Only on best sellers product</p>
            <button>check now</button>
        </div>
        <div className='offers-right'>
<img src={exclusive_image} />
        </div>

    </div>
  )
}

export default Offers
